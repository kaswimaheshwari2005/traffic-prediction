import pandas as pd
import numpy as np

np.random.seed(42)
n_samples = 5000

data = {
    "throughput": np.random.uniform(10, 100, n_samples),
    "latency": np.random.uniform(5, 50, n_samples),
    "packet_loss": np.random.uniform(0, 5, n_samples),
    "rb_utilization": np.random.uniform(20, 90, n_samples),
    "handover_success": np.random.uniform(70, 100, n_samples),
    "signal_strength": np.random.uniform(-110, -60, n_samples),
}

data["traffic_load"] = (
    0.4 * data["throughput"]
    - 0.2 * data["latency"]
    + 0.3 * data["rb_utilization"]
    + np.random.normal(0, 5, n_samples)
)

df = pd.DataFrame(data)
df.to_csv("data/traffic_dataset.csv", index=False)
print("✅ Dataset saved to data/traffic_dataset.csv")
