# preprocess.py
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import joblib

# 1️⃣ Load the raw dataset
data = pd.read_csv("data/traffic_dataset.csv")
print("Columns in dataset:", data.columns.tolist())

# 2️⃣ Handle missing values
data = data.fillna(data.mean())

# 3️⃣ Automatically detect target column (assume last column)
target_column = data.columns[-1]
print("Detected target column:", target_column)

# 4️⃣ Split features and target
X = data.drop(target_column, axis=1)
y = data[target_column]

# 5️⃣ Scale features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
X_scaled = pd.DataFrame(X_scaled, columns=X.columns)

# 6️⃣ Combine scaled features with target
processed_data = X_scaled.copy()
processed_data[target_column] = y

# 7️⃣ Save the processed dataset
processed_data.to_csv("data/processed_traffic.csv", index=False)
print("✅ Dataset preprocessed and saved to data/processed_traffic.csv")

# 8️⃣ Optional: save train-test split for later
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)
joblib.dump((X_train, X_test, y_train, y_test), "data/split_data.joblib")
print("✅ Train-test split saved to data/split_data.joblib")
