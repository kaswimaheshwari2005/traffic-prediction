from flask import Flask, request, jsonify
import joblib
import pandas as pd

app = Flask(__name__)

# Load preprocessing objects and trained model
scaler = joblib.load("models/scaler.joblib")
selector = joblib.load("models/selector.joblib")
imputer = joblib.load("models/imputer.joblib")
model = joblib.load("models/stacking.joblib")  # best model

@app.route("/")
def home():
    return "✅ Traffic Load Prediction API is running!"

@app.route("/predict", methods=["POST"])
def predict():
    data = request.json
    df = pd.DataFrame([data])

    # Apply preprocessing steps
    X_imp = imputer.transform(df)
    X_sel = selector.transform(X_imp)
    X_scaled = scaler.transform(X_sel)

    # Predict (no PCA now)
    prediction = model.predict(X_scaled)[0]
    return jsonify({"prediction": float(prediction)})

if __name__ == "__main__":
    app.run(debug=True, port=5000)
