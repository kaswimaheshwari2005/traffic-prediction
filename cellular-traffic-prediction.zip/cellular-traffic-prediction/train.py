import os
from sklearn.model_selection import train_test_split

from preprocess import load_data, basic_clean, impute_and_select, scale_and_pca
from modeling import train_random_forest, train_xgboost, train_stacking, evaluate_model

# Ensure models folder exists
os.makedirs("models", exist_ok=True)

def main():
    # Load dataset
    df = load_data("data/traffic_dataset.csv")
    df_num = basic_clean(df)

    target_col = "traffic_load"
    X_sel, y = impute_and_select(df_num, target_col, k_features=5)

    # Split dataset
    X_train, X_test, y_train, y_test = train_test_split(
        X_sel, y, test_size=0.2, random_state=42
    )

    # Train models
    rf = train_random_forest(X_train, y_train)
    xgb = train_xgboost(X_train, y_train)
    stack = train_stacking(X_train, y_train)

    # Evaluate
    print("Random Forest:", evaluate_model(rf, X_test, y_test))
    print("XGBoost:", evaluate_model(xgb, X_test, y_test))
    print("Stacking:", evaluate_model(stack, X_test, y_test))

if __name__ == "__main__":
    main()
