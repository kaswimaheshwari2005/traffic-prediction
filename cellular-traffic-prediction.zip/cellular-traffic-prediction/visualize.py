import joblib
import matplotlib.pyplot as plt
import pandas as pd

# 1️⃣ Load train-test split
X_train, X_test, y_train, y_test = joblib.load("data/split_data.joblib")

# 2️⃣ Load preprocessing artifacts
imputer = joblib.load("models/imputer.joblib")
scaler = joblib.load("models/scaler.joblib")
selector = joblib.load("models/selector.joblib")

# 3️⃣ Apply preprocessing to X_test
X_test_imputed = imputer.transform(X_test)
X_test_scaled = scaler.transform(X_test_imputed)
X_test_selected = selector.transform(X_test_scaled)

# 4️⃣ Load trained model
model = joblib.load("models/random_forest.joblib")

# 5️⃣ Make predictions
y_pred = model.predict(X_test_selected)

# 6️⃣ Plot actual vs predicted
plt.figure(figsize=(10,6))
plt.plot(y_test.values, label="Actual Traffic Load", color="blue")
plt.plot(y_pred, label="Predicted Traffic Load", color="red", linestyle="--")
plt.title("Actual vs Predicted Traffic Load")
plt.xlabel("Sample Index")
plt.ylabel("Traffic Load")
plt.legend()
plt.grid(True)
plt.tight_layout()

# 7️⃣ Save and show plot
plt.savefig("data/traffic_prediction_plot.png")
plt.show()

print("✅ Visualization completed and saved as traffic_prediction_plot.png")
