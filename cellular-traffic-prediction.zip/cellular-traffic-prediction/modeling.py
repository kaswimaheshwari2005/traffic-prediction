from sklearn.ensemble import RandomForestRegressor, StackingRegressor
from xgboost import XGBRegressor
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_percentage_error
import joblib

# Train a Random Forest model
def train_random_forest(X, y):
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X, y)
    joblib.dump(model, "models/random_forest.joblib")
    return model

# Train an XGBoost model
def train_xgboost(X, y):
    model = XGBRegressor(n_estimators=100, learning_rate=0.1, tree_method="hist", verbosity=0)
    model.fit(X, y)
    joblib.dump(model, "models/xgboost.joblib")
    return model

# Train a Stacking Ensemble model
def train_stacking(X, y):
    estimators = [
        ("rf", RandomForestRegressor(n_estimators=80, random_state=42)),
        ("xgb", XGBRegressor(n_estimators=80, learning_rate=0.08, verbosity=0)),
    ]
    model = StackingRegressor(
        estimators=estimators,
        final_estimator=RandomForestRegressor(n_estimators=50, random_state=42),
    )
    model.fit(X, y)
    joblib.dump(model, "models/stacking.joblib")
    return model

# Evaluate a model
def evaluate_model(model, X_test, y_test):
    preds = model.predict(X_test)
    return {
        "MSE": mean_squared_error(y_test, preds),
        "R2": r2_score(y_test, preds),
        "MAPE": mean_absolute_percentage_error(y_test, preds) * 100,
    }
